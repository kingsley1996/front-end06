/*
Muc tieu: xay dung trang quan ly nhan vien ( them ,sua xoa, tim kiem)
Nguoi tao : Dang Ngoc Linh
Ngay tao: 1/4/2018
version: 1.0

*/

//Tạo mảng lưu trữ các thông báo

var mangThongBao = [
    "Vui lòng nhập Họ !", //[0]
    "Vui lòng nhập Tên !", //[1]   
    "Vui lòng nhập mã số nv !", //[2]
    "Vui lòng chọn chức vụ !", //[3]
    "Nhập tên phải là kí tự !", //[4]
    "Nhập họ phải là kí tự !", //[5]
    "Chiều dài tối thiểu, tối đa ", //[6]
    "Vui lòng nhập email!", //[7]
    "Email không hợp lệ", //[8]
    "Vui lòng nhập lương cơ bản", //[9]
    "Vui lòng nhập lương là số", //[10]
    "Vui lòng nhập phụ cấp", //[11]
    "Vui lòng nhập phụ cấp là số" //[12]
];

//Hàm rút gọn để lấy phần tử bằng id
function getMyEle(ele) {
    return document.getElementById(ele);
}

/*
Mục tiêu hàm: kiểm tra các trường dữ liệu có được nhập hay không!?,rồi xuất thông báo yêu cầu nhập.
Nguoi tao : Dang Ngoc Linh
Ngay tao: 1/4/2018
version: 1.0
*/

function kiemTraNhap(idField, idThongBao, indexChuoiTB) {
    var kq = false;
    var valueField = getMyEle(idField).value;
    var thongBao = getMyEle(idThongBao);
    if (valueField === "") {
        var kq = false;
        thongBao.style.display = "block";
        thongBao.innerHTML = mangThongBao[indexChuoiTB];
    } else {
        thongBao.style.display = "none";
        var kq = true;
    }
    if (!kq) {
        getMyEle(idField).style.color = "orange";
    } else {
        getMyEle(idField).style.color = "#28a745";
    }
    return kq; //return về kq để nếu kq=true thì thực hiện tiếp các hàm bên dưới

}

/*
Mục tiêu hàm: kiểm tra xem người dùng có chọn chức vụ hay không, nếu không chọn xuất tb yêu cầu chọn
Nguoi tao : Dang Ngoc Linh
Ngay tao: 1/4/2018
version: 1.0
*/

function kiemTraChon() {
    var kq = false;
    var selectCV = getMyEle('chucVu');
    var thongBaoChucVu = getMyEle('thongBaoChucVu');
    if (selectCV.selectedIndex === 0) { //thuộc tính selectedIndex để biết ng dùng đang chọn giá trị nào
        thongBaoChucVu.style.display = "block";
        thongBaoChucVu.innerHTML = mangThongBao[3];
        var kq = false;
    } else {
        thongBaoChucVu.style.display = "none";
        var kq = true;
    }
    return kq;
}

/*
Mục tiêu hàm: kiểm tra chỉ nhập ký tự
Nguoi tao : Dang Ngoc Linh
Ngay tao: 1/4/2018
version: 1.0
*/

function kiemTraNhapKiTu(idField, idThongBao, indexChuoiTB) {
    var mangKiTu = /^[A-Za-z]+$/; //Chuỗi Javascript Regular Expression - Biểu thức chính quy
    var valueField = getMyEle(idField).value;
    var thongBao = getMyEle(idThongBao);
    if (valueField.match(mangKiTu)) { //hàm match kiểm tra xem chuỗi nhập vào có phải là ký tự hay k
        thongBao.style.display = "none";
        var kq = true;
    } else {
        thongBao.style.display = "block";
        thongBao.innerHTML = mangThongBao[indexChuoiTB];
        var kq = false;
    }
    if (!kq) {
        getMyEle(idField).style.color = "orange";
    } else {
        getMyEle(idField).style.color = "#28a745";
    }
    return kq;

}

/*
Muc tieu : kiem tra nhap la so

*/

function kiemTraNhapSo(idField, idThongBao, indexChuoiTB) {
    var mangSo = /^[0-9]+$/; //Chuỗi Javascript Regular Expression - Biểu thức chính quy
    var valueField = getMyEle(idField).value;
    var thongBao = getMyEle(idThongBao);
    if (valueField.match(mangSo)) { //hàm match kiểm tra xem chuỗi nhập vào có phải là ký tự hay k
        thongBao.style.display = "none";
        var kq = true;
    } else {
        thongBao.style.display = "block";
        thongBao.innerHTML = mangThongBao[indexChuoiTB];
        var kq = false;
    }
    if (!kq) {
        getMyEle(idField).style.color = "orange";
    } else {
        getMyEle(idField).style.color = "#28a745";
    }
    return kq;

}

/*
Mục tiêu hàm: kiểm tra độ dài chuỗi mã số nhân viên
Nguoi tao : Dang Ngoc Linh
Ngay tao: 1/4/2018
version: 1.0
*/

function KiemTraDoDai(minLength, maxLength, indexChuoiTB) {
    var valueField = getMyEle('msnv').value;
    var thongBao = getMyEle('thongBaoMaNV');
    if (valueField.length < minLength || valueField.length > maxLength) {
        thongBao.style.display = "block";
        thongBao.innerHTML = mangThongBao[indexChuoiTB] + "từ : " + minLength + "-" + maxLength + " kí tự!";
        var kq = false;
    } else {
        thongBao.style.display = "none";
        var kq = true;
    }
    if (!kq) {
        getMyEle('msnv').style.color = "orange";
    } else {
        getMyEle('msnv').style.color = "#28a745";
    }
    return kq;
}

/*
Mục tiêu hàm: kiểm tra định dạng email
Nguoi tao : Dang Ngoc Linh
Ngay tao: 5/4/2018
version: 1.0
*/

function kiemTraNhapEmail(idField, idThongBao, indexChuoiTB) {

    var mangEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; //Chuỗi Javascript Regular Expression - Biểu thức chính quy
    var valueField = getMyEle(idField).value;
    var thongBao = getMyEle(idThongBao);
    if (valueField.match(mangEmail)) { //hàm match kiểm tra xem chuỗi nhập vào có phải là ký tự hay k
        thongBao.style.display = "none";
        var kq = true;
    } else {
        thongBao.style.display = "block";
        thongBao.innerHTML = mangThongBao[indexChuoiTB];
        var kq = false;
    }
    if (!kq) {
        getMyEle(idField).style.color = "orange";
    } else {
        getMyEle(idField).style.color = "#28a745";
    }
    return kq;
}

/*
Muc tieu : kiem tra hop le
*/
function kiemTraHopLe() {
    var kq = false;
    //gán biến kq = kq của hàm kiemTraNhap
    //Nếu kq = true thì mới thực hiện hàm kiemTrNhapKiTu
    //Có nghĩa là kiểm tra xem người dùng đã nhập giá trị chưa, nếu nhập rồi mới kiểm tra xem ng dùng có nhập kí tự đúng hay không!
    var kq1 = kiemTraNhap("ho", "thongBaoHo", 0);
    if (kq1) {
        var kq2 = kiemTraNhapKiTu("ho", "thongBaoHo", 5);
    }
    var kq3 = kiemTraNhap("ten", "thongBaoTen", 1);
    if (kq3) {
        var kq4 = kiemTraNhapKiTu("ten", "thongBaoTen", 4);
    }
    //Tương tự kiểm tra ng dùng đã nhập msnv chưa, nếu nhập rồi thì mới kiểm tra độ dài của msnv
    var kq5 = kiemTraNhap("msnv", "thongBaoMaNV", 2);
    if (kq5) {
        var kq6 = KiemTraDoDai(4, 6, 6);
    }

    //kiểm tra email đã nhập chưa, nhập rồi thì kiểm tra định dạng xem có đúng k
    var kq7 = kiemTraNhap("email", "thongBaoEmail", 7);
    if (kq7) {
        var kq8 = kiemTraNhapEmail("email", "thongBaoEmail", 8);
    }
    var kq9 = kiemTraChon();
    var kq10 = kiemTraNhap("luongCB", "thongBaoLuongCB", 9);
    if (kq10) {
        var kq11 = kiemTraNhapSo("luongCB", "thongBaoLuongCB", 10);
    }
    var kq12 = kiemTraNhap("phuCap", "thongBaoPhuCap", 11);
    if (kq12) {
        var kq13 = kiemTraNhapSo("phuCap", "thongBaoPhuCap", 12);
    }
    if (kq1 && kq2 && kq3 && kq4 && kq5 && kq6 && kq7 && kq8 && kq9 && kq10 && kq11 && kq12 && kq13) {
        var kq = true;
    }
    return kq;

}
/*
Muc tieu : reset form
*/
function resetForm() {
    getMyEle('formNhanVien').reset();
//    getMyEle('formTimKiem').reset();
}

/*
Muc tieu: ham tao Dong 
*/

function taoDong(tBody, nv) {
    var row = document.createElement('tr');
    tBody.appendChild(row);
    for (var i = 0; i < nv.mangThuocTinh.length - 2; i++) {
        var td = document.createElement('td');
        row.appendChild(td);
        td.innerHTML = nv.mangThuocTinh[i];
    }
    var tdLuong = document.createElement('td');
    row.appendChild(tdLuong);
    tdLuong.innerHTML = parseFloat(nv.luongCoBan) + parseFloat(nv.phuCap) + " USD";
    var btnSua = "<button type='button' class='btn btn-sua mr-1' value='Sua' id='sua_" + nv.maNV + "'>Sửa</button>";
    var btnCapNhat = "<button type='button' class='btn btnCapNhat' value='CapNhat' id='capnhat_" + nv.maNV + "'>Cập nhật</button>";
    var btnXoa = "<button type='button' class='btn' value='Xoa' id='xoa_" + nv.maNV + "'>Xóa</button>";
    var td = document.createElement('td');
    row.appendChild(td);
    td.innerHTML = btnSua + btnCapNhat + btnXoa;
    deleteHandler("xoa_" + nv.maNV);
    editHandler("sua_" + nv.maNV);
    saveHandler("capnhat_" + nv.maNV);
}

function xuLyThemNhanVienVaoTable() {
    var tBody = getMyEle("hienThiNV");
    var soNhanVien = dsNhanVien.soLuongNhanVien();
    dsNhanVien.xuatThuocTinhNV();
    tBody.innerHTML = "";
    for (var i = 0; i < soNhanVien; i++) {
        var nhanvien = dsNhanVien.danhSachNV[i];
        taoDong(tBody, nhanvien);
    }
}



function deleteHandler(eleID) {
    getMyEle(eleID).addEventListener("click", function () {
        var id = this.id;
        var mangTemp = id.split("_");
        dsNhanVien.xoaNhanVien(mangTemp[1]);
        xuLyThemNhanVienVaoTable();
    });
}

function editHandler(eleID) {
    getMyEle(eleID).addEventListener("click", function () {
        var table = getMyEle('tableHienThi');
        var id = this.id;
        var mangTemp = id.split("_");
        var nhanVienEdit = dsNhanVien.timNhanVien(mangTemp[1]);

        //lay row hien hanh chua nut
        var currentRow = this.parentNode.parentNode.rowIndex;
        //tao ra cac text box tu mang thuoc tinh dua vao so luong thuoc tinh
        var soThuocTinh = nhanVienEdit.soThuocTinh();
        for (var i = 0; i < soThuocTinh - 2; i++) {
            var valueTextBox = nhanVienEdit.mangThuocTinh[i];
            var textbox = "<input type='text' value='" + valueTextBox + "'>";
            //gan textbox nam trong td cua table
            table.rows[currentRow].cells[i].innerHTML = textbox;
            //            table.rows[currentRow].cells[i].value = valueTextBox;
            //            console.log(valueTextBox);
        }
        // an nut sua
        this.style.display = "none";
        //bat nut cap nhat
        getMyEle("capnhat_" + mangTemp[1]).style.display = "inline-block";
    });
}

function saveHandler(eleID) {
    getMyEle(eleID).addEventListener("click", function () {
        var table = getMyEle('tableHienThi');
        var id = this.id;
        var mangTemp = id.split("_");
        var nhanVien = dsNhanVien.timNhanVien(mangTemp[1]);
        //        nhanVienEdit.mangThuocTinh = [];
        //lay row hien hanh chua nut
        var currentRow = this.parentNode.parentNode.rowIndex;
        //tao ra cac text box tu mang thuoc tinh dua vao so luong thuoc tinh
        var soThuocTinh = nhanVien.soThuocTinh();
        var mangSave = [];
        for (var i = 0; i < soThuocTinh - 2; i++) {
            valueUpdate = table.rows[currentRow].cells[i].firstChild.value;
            //table.rows[currentRow].cells[i].innerHTML = valueUpdate;
            mangSave.push(valueUpdate);

        }
        mangSave.push(nhanVien.luongCoBan);
        mangSave.push(nhanVien.phuCap);
        nhanVien.mangThuocTinh = mangSave;
        var maNV = nhanVien.mangThuocTinh[0];
        var ho = nhanVien.mangThuocTinh[1];
        var ten = nhanVien.mangThuocTinh[2];
        var email = nhanVien.mangThuocTinh[3];
        var chucVu = nhanVien.mangThuocTinh[4];
        var ngayLam = nhanVien.mangThuocTinh[5];
        var luongCB = nhanVien.mangThuocTinh[6];
        var phuCap = nhanVien.mangThuocTinh[7];
        var nhanVienUpdate = new NhanVien(maNV, ho, ten, email, chucVu, ngayLam, luongCB, phuCap);
        nhanVienUpdate.mangThuocTinh = mangSave;
        dsNhanVien.xoaNhanVien(mangTemp[1]);
        dsNhanVien.themNhanVien(nhanVienUpdate);

        //ẩn nút cập nhật
        this.style.display = "none";
        //hiện nút sửa
        getMyEle("sua_" + mangTemp[1]).style.display = "inline-block";
        luuDanhSachNhanVien();
        xuLyThemNhanVienVaoTable();

    });
}

/*
Mục tiêu hàm: lắng nghe sự kiện 'Click' của nút "Thêm NV", tức là khi click vào nút thêm sẽ thực hiện hàm này.
Nguoi tao : Dang Ngoc Linh
Ngay tao: 1/4/2018
version: 1.0
*/

//Bien toan cuc luu tru toan bo du lieu
var dsNhanVien = new DanhSachNV();
var dsNhanVienTK = new DanhSachNV();
getMyEle('btnThemNV').addEventListener("click", function () {
    var ktHopLe = kiemTraHopLe();
    if (ktHopLe) {
        var hienThi = getMyEle("hienThi");
        hienThi.style.display = "block";
        var timKiem = getMyEle("timKiem");
        timKiem.style.display = "block";
        var ho = getMyEle('ho').value;
        var ten = getMyEle('ten').value;
        var maNV = getMyEle('msnv').value;
        var email = getMyEle('email').value;
        var ngayLam = getMyEle('datepicker').value;
        var chucVu = getMyEle('chucVu').value;
        var luongCB = getMyEle('luongCB').value;
        var phuCap = getMyEle('phuCap').value;
        var nhanvien = new NhanVien(maNV, ho, ten, email, chucVu, ngayLam, luongCB, phuCap);
        dsNhanVien.themNhanVien(nhanvien);
        resetForm();
        xuLyThemNhanVienVaoTable();
    }
});
getMyEle('nutTimKiem').addEventListener("click", function () {
    var kqTimKiem = getMyEle('kqTimKiem');
    var tBody = getMyEle("hienThiTK");
    var tableTimKiem = getMyEle('tableTimKiem');
    tBody.innerHTML = "";

    var tenNV = getMyEle('searchField').value.trim().toLowerCase();
    getMyEle('searchField').value = "";
    var nhanVien = dsNhanVien.timNhanVienTheoTen(tenNV);
    //    console.log(nhanVien);
    for (var i = 0; i < nhanVien.length; i++) {
        dsNhanVienTK.themNhanVien(nhanVien[i]);
    }

    if (dsNhanVienTK.danhSachNV.length == 0) {
        tableTimKiem.style.display = "none";
        var khongTimThay = document.createElement('h3');
        khongTimThay.style.color = "red";
        khongTimThay.style.textAlign = "center";
        kqTimKiem.appendChild(khongTimThay);
        if (tenNV == "") {
            khongTimThay.innerHTML = "Vui lòng nhập vào tên nhân viên muốn tìm!";

        } else if (tenNV !== "") {
            khongTimThay.innerHTML = "Không tìm thấy '" + tenNV + "'" + " trong danh sách nhân viên!";
        }


    } else {
        var kqTimThay = document.createElement('h5');
        kqTimThay.style.color = "white";
        kqTimThay.style.fontStyle = "italic";
        kqTimThay.innerHTML = "Hệ thống tìm được " + dsNhanVienTK.danhSachNV.length + " kết quả cho từ khóa '" + tenNV + "':";
        kqTimKiem.appendChild(kqTimThay);
        tableTimKiem.style.display = "block";
        xuLyXuatDanhSachNVTimThay();
        dsNhanVienTK.danhSachNV = [];
    }
});

/*
Muc tieu ham: xuat ra danh sach tim kiem
Nguoi tao : Dang Ngoc Linh
Ngay tao: 1/4/2018
version: 1.0
*/

function taoDongTK(tBody, nv) {
    var row = document.createElement('tr');
    tBody.appendChild(row);
    for (var i = 0; i < nv.mangThuocTinh.length - 2; i++) {
        var td = document.createElement('td');
        row.appendChild(td);
        td.innerHTML = nv.mangThuocTinh[i];
    }
    var tdLuong = document.createElement('td');
    row.appendChild(tdLuong);
    tdLuong.innerHTML = parseFloat(nv.luongCoBan) + parseFloat(nv.phuCap) + " USD";
}

function xuLyXuatDanhSachNVTimThay() {
    var tBody = getMyEle("hienThiTK");
    var soNhanVien = dsNhanVienTK.soLuongNhanVien();
    dsNhanVienTK.xuatThuocTinhNV();
    tBody.innerHTML = "";
    for (var i = 0; i < soNhanVien; i++) {
        var nhanvien = dsNhanVienTK.danhSachNV[i];
        taoDongTK(tBody, nhanvien);
    }

}

getMyEle('closeTK').addEventListener("click", function () {
    var tBody = getMyEle("hienThiTK");
    tBody.innerHTML = "";
    var kqTimKiem = getMyEle('kqTimKiem');
    kqTimKiem.innerHTML = "";
    var tenNV = getMyEle('searchField').value;
    tenNV = null;
});

//Lưu danh sách người dùng vào localStorage
    function luuDanhSachNhanVien() {
        //chuyển đổi mảng DSND -> chuỗi
        var jsonDSNV = JSON.stringify(dsNhanVien.danhSachNV);
        //lưu ý: chỉ lưu được dữ liêu, k lưu đc phương thức
        localStorage.setItem("DanhSachNhanVien", jsonDSNV);
    }

    //lấy danh sách người dùng từ localStorage
    function layDanhSachNhanVien() {
        if (localStorage.getItem("DanhSachNhanVien")) {
            //lấy chuỗi từ localStorage
            var jsonDSNV = localStorage.getItem("DanhSachNhanVien");
            //Parse chuỗi json -> object là mảng DSND
            dsNhanVien.danhSachNV = JSON.parse(jsonDSNV);
            //goi phuong thuc load table nguoi dung
            xuLyThemNhanVienVaoTable();
        }
    }

    //Goi ham lay danh sach Nguoi dung khi script vua load xong
    layDanhSachNhanVien();