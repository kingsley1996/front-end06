/*
Muc tieu : tao ra prototype Nhan Vien
Nguoi tao : Dang Ngoc Linh
Ngay tao : 14h37' - 7/4/2018
Version: 1.0
*/

function NhanVien(maNV, ho, ten, email, chucVu,
    ngayLamViec, luongCoBan, phuCap) {
    //Cac thuoc tinh cua prototype NhanVien
    this.maNV = maNV;
    this.ho = ho;
    this.ten = ten;
    this.email = email;
    //    this.ngaySinh = ngaySinh;
    this.chucVu = chucVu;
    this.soNgayLamViec = ngayLamViec;
    this.luongCoBan = luongCoBan;
    this.phuCap = phuCap;
    this.mangThuocTinh = [];
    //tao mang chua tat ca thuoctinh de xu ly nang cao

    //Cach 1: Cac phuong thuc cua prototype NhanVien
    //    this.tinhLuong = function () {
    //      return  ngayLamViec * luongCoBan + phuCap    
    //    };
}
//Cach 2: khai bao phuong thuc cho prototype co san
NhanVien.prototype.tinhLuong = function () {
    var luongNV = parseFloat(this.luongCoBan) + parseFloat(this.phuCap) + " USD";
    return luongNV;
};
NhanVien.prototype.xuatThuocTinh = function () {
    this.mangThuocTinh = [this.maNV, this.ho, this.ten, this.email,
                         this.chucVu, this.soNgayLamViec, this.luongCoBan,this.phuCap];

}
NhanVien.prototype.soThuocTinh = function () {
    return this.mangThuocTinh.length;
}
