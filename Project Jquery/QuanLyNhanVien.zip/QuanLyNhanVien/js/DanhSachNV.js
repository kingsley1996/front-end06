/*
Muc tieu : tao ra prototype Nhan Vien
Nguoi tao : Dang Ngoc Linh
Ngay tao : 14h37' - 7/4/2018
Version: 1.0
*/

function DanhSachNV() {
    this.danhSachNV = [];
    this.themNhanVien = function (nv) {
        this.danhSachNV.push(nv);
    };
    this.xuatLuong = function () {
        for (var i = 0; i < this.danhSachNV.length; i++) {
            this.danhSachNV[i].tinhLuong();
        }
    };
}
////Them nhan vien vao danh sach nhan vien
//DanhSachNV.prototype.themNhanVien = function(nv) {
//    this.danhSachNV.push(nv);
//}
DanhSachNV.prototype.xuatLuong = function () {
    var soNhanVien = this.danhSachNV.length;
    for (var i = 0; i < soNhanVien; i++) {
        this.danhSachNV[i].tinhLuong();
    }
};

DanhSachNV.prototype.timIndexNhanVien = function (maNV) {
    var indexFound = -1;
    for (var i = 0; i < this.danhSachNV.length; i++) {
        if (this.danhSachNV[i].maNV === maNV) {
            indexFound = i;
            break;
        }
    }
    return indexFound;
}
DanhSachNV.prototype.timNhanVien = function (maNV) {
    var nhanVien = null;
    for (var i = 0; i < this.danhSachNV.length; i++) {
        if (this.danhSachNV[i].maNV === maNV) {
            nhanVien = i;
            break;
        }
    }
    return this.danhSachNV[nhanVien];
}
DanhSachNV.prototype.xoaNhanVien = function (maNV) {
    var indexNhanVien = this.timIndexNhanVien(maNV);
    if (indexNhanVien >= 0) {
        this.danhSachNV.splice(indexNhanVien, 1);
    }
};

//DanhSachNV.prototype.updateNhanVien = function (maNV, nhanVien) {
//    var indexNhanVien = this.timIndexNhanVien(maNV);
//    if (indexNhanVien >= 0) {
//        var nhanVien = new NhanVien();
//        this.danhSachNV[indexNhanVien] = nhanVien;
//    }
//};


DanhSachNV.prototype.xuatThuocTinhNV = function () {
    for (var i = 0; i < this.danhSachNV.length; i++) {
        this.danhSachNV[i].xuatThuocTinh();
    }
};

DanhSachNV.prototype.soLuongNhanVien = function () {
    return this.danhSachNV.length;
}

/*
Muc tieu ham : tim nhan vien theo ten
Nguoi tao : Dang Ngoc Linh
Ngay tao : 13/4/2018
Version: 1.0
*/

DanhSachNV.prototype.timNhanVienTheoTen = function (tenNV) {
    var mangNhanVien = [];
    for (var i = 0; i < this.danhSachNV.length; i++) {
        var hoTenNV = this.danhSachNV[i].ho + " " + this.danhSachNV[i].ten;
        if (tenNV !== "") {
            var kq = hoTenNV.trim().toLowerCase().indexOf(tenNV);
            if (kq >= 0) {
                mangNhanVien.push(this.danhSachNV[i]);
            }
        }
    }
    return mangNhanVien;
}
